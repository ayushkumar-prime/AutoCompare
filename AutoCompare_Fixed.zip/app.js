"use strict";

const cars = [
  {id:1,brand:"Mercedes-Benz",model:"C-Class",category:"Luxury",price:60,fuel:"Petrol",transmission:"Automatic",power:204,seats:5,range:"14 kmpl",engine:"2.0L turbo petrol"},
  {id:2,brand:"BMW",model:"3 Series Gran Limousine",category:"Luxury",price:62,fuel:"Diesel",transmission:"Automatic",power:190,seats:5,range:"19 kmpl",engine:"2.0L turbo diesel"},
  {id:3,brand:"Audi",model:"A4",category:"Luxury",price:47,fuel:"Petrol",transmission:"Automatic",power:190,seats:5,range:"15 kmpl",engine:"2.0L turbo petrol"},
  {id:4,brand:"Porsche",model:"911 Carrera",category:"Sports",price:190,fuel:"Petrol",transmission:"Automatic",power:379,seats:4,range:"9 kmpl",engine:"3.0L twin-turbo"},
  {id:5,brand:"Chevrolet",model:"Corvette Stingray",category:"Sports",price:150,fuel:"Petrol",transmission:"Automatic",power:482,seats:2,range:"8 kmpl",engine:"6.2L V8"},
  {id:6,brand:"Tesla",model:"Model 3",category:"Electric",price:45,fuel:"Electric",transmission:"Automatic",power:283,seats:5,range:"420 km range",engine:"Dual electric motors"},
  {id:7,brand:"BYD",model:"Seal",category:"Electric",price:42,fuel:"Electric",transmission:"Automatic",power:308,seats:5,range:"360 km range",engine:"Dual electric motors"},
  {id:8,brand:"Tata",model:"Nexon EV",category:"Electric",price:15,fuel:"Electric",transmission:"Automatic",power:129,seats:5,range:"325 km range",engine:"Electric motor"},
  {id:9,brand:"Toyota",model:"Fortuner",category:"SUV",price:35,fuel:"Diesel",transmission:"Automatic",power:204,seats:7,range:"11 kmpl",engine:"2.8L turbo diesel"},
  {id:10,brand:"Mahindra",model:"XUV700",category:"SUV",price:18,fuel:"Diesel",transmission:"Manual",power:182,seats:7,range:"15 kmpl",engine:"2.2L turbo diesel"},
  {id:11,brand:"Hyundai",model:"Creta",category:"SUV",price:12,fuel:"Petrol",transmission:"Manual",power:115,seats:5,range:"17 kmpl",engine:"1.5L petrol"},
  {id:12,brand:"Honda",model:"City",category:"Sedan",price:12,fuel:"Petrol",transmission:"Manual",power:121,seats:5,range:"17.8 kmpl",engine:"1.5L petrol"},
  {id:13,brand:"Toyota",model:"Camry",category:"Sedan",price:47,fuel:"Hybrid",transmission:"Automatic",power:230,seats:5,range:"19 kmpl",engine:"2.5L hybrid"},
  {id:14,brand:"Skoda",model:"Slavia",category:"Sedan",price:11.5,fuel:"Petrol",transmission:"Manual",power:115,seats:5,range:"19 kmpl",engine:"1.0L turbo petrol"},
  {id:15,brand:"Maruti Suzuki",model:"Alto K10",category:"Budget",price:4.2,fuel:"Petrol",transmission:"Manual",power:67,seats:4,range:"24 kmpl",engine:"1.0L petrol"},
  {id:16,brand:"Tata",model:"Tiago",category:"Budget",price:5,fuel:"Petrol",transmission:"Manual",power:86,seats:5,range:"20 kmpl",engine:"1.2L petrol"},
  {id:17,brand:"Renault",model:"Kwid",category:"Budget",price:4.7,fuel:"Petrol",transmission:"Manual",power:68,seats:5,range:"21 kmpl",engine:"1.0L petrol"}
];

const $ = (selector) => document.querySelector(selector);
const money = (price) => price >= 100 ? `₹${(price / 100).toFixed(2)} crore` : `₹${price} lakh`;
const safeText = (value) => String(value).replace(/[&<>"']/g, char => ({
  "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
}[char]));
const toast = (message) => {
  const box = $("#toast");
  box.textContent = message;
  box.style.display = "block";
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => { box.style.display = "none"; }, 2600);
};

function renderCars() {
  const query = $("#searchInput").value.trim().toLowerCase();
  const category = $("#categoryFilter").value;
  const sort = $("#sortFilter").value;
  let filtered = cars.filter(car => {
    const matchesQuery = `${car.brand} ${car.model} ${car.category}`.toLowerCase().includes(query);
    return matchesQuery && (!category || car.category === category);
  });
  filtered.sort((a, b) => sort === "high" ? b.price - a.price : sort === "power" ? b.power - a.power : a.price - b.price);
  $("#resultCount").textContent = `${filtered.length} car${filtered.length === 1 ? "" : "s"} found`;
  $("#carGrid").innerHTML = filtered.length ? filtered.map(car => `
    <article class="car-card">
      <div class="car-art" aria-hidden="true"><span>🚘</span></div>
      <div class="car-info">
        <span class="car-category">${safeText(car.category)}</span>
        <h3>${safeText(car.brand)} ${safeText(car.model)}</h3>
        <div class="price">${money(car.price)}</div>
        <div class="spec-line">${safeText(car.fuel)} · ${safeText(car.transmission)} · ${car.seats} seats</div>
        <div class="spec-line">${car.power} hp · ${safeText(car.range)}</div>
        <div class="card-actions"><button class="btn" data-compare="${car.id}">Add to compare</button></div>
      </div>
    </article>`).join("") : `<p class="muted">No cars match those filters. Try another search.</p>`;
}

function fillCompareOptions() {
  const options = cars.map(car => `<option value="${car.id}">${safeText(car.brand)} ${safeText(car.model)}</option>`).join("");
  $("#carOne").innerHTML = options;
  $("#carTwo").innerHTML = options;
  $("#carTwo").selectedIndex = Math.min(1, cars.length - 1);
}

function compareCars(firstId, secondId) {
  const first = cars.find(car => car.id === Number(firstId));
  const second = cars.find(car => car.id === Number(secondId));
  if (!first || !second || first.id === second.id) {
    $("#comparisonResult").innerHTML = `<p class="form-message">Please choose two different cars.</p>`;
    return;
  }
  const rows = [
    ["Price", money(first.price), money(second.price), first.price < second.price ? 1 : second.price < first.price ? 2 : 0],
    ["Category", first.category, second.category, 0],
    ["Fuel", first.fuel, second.fuel, 0],
    ["Engine / motor", first.engine, second.engine, 0],
    ["Power", `${first.power} hp`, `${second.power} hp`, first.power > second.power ? 1 : second.power > first.power ? 2 : 0],
    ["Transmission", first.transmission, second.transmission, 0],
    ["Seats", first.seats, second.seats, first.seats > second.seats ? 1 : second.seats > first.seats ? 2 : 0],
    ["Mileage / range", first.range, second.range, 0]
  ];
  $("#comparisonResult").innerHTML = `<table class="comparison-table"><thead><tr><th>Specification</th><th>${safeText(first.brand)} ${safeText(first.model)}</th><th>${safeText(second.brand)} ${safeText(second.model)}</th></tr></thead><tbody>${rows.map(row => `<tr><th>${row[0]}</th><td class="${row[3] === 1 ? "winner" : ""}">${safeText(row[1])}</td><td class="${row[3] === 2 ? "winner" : ""}">${safeText(row[2])}</td></tr>`).join("")}</tbody></table><p class="muted">Green highlights indicate a simple numeric advantage, not an overall recommendation. Prices are sample estimates.</p>`;
}

function setAuthMode(mode) {
  const login = mode === "login";
  $("#loginForm").hidden = !login;
  $("#signupForm").hidden = login;
  $("#loginTab").classList.toggle("active", login);
  $("#signupTab").classList.toggle("active", !login);
  $("#loginMessage").textContent = "";
  $("#signupMessage").textContent = "";
}

function getUsers() {
  try { return JSON.parse(localStorage.getItem("autocompare_users") || "{}"); }
  catch { return {}; }
}
function saveUsers(users) {
  try { localStorage.setItem("autocompare_users", JSON.stringify(users)); return true; }
  catch { return false; }
}
function updateAccountUI() {
  let current = null;
  try { current = JSON.parse(sessionStorage.getItem("autocompare_session") || "null"); } catch {}
  $("#accountLink").textContent = current ? `Hi, ${current.name}` : "Login / Sign up";
  $("#logoutBtn").hidden = !current;
}

document.addEventListener("DOMContentLoaded", () => {
  $("#searchInput").addEventListener("input", renderCars);
  $("#categoryFilter").addEventListener("change", renderCars);
  $("#sortFilter").addEventListener("change", renderCars);
  $("#compareBtn").addEventListener("click", () => compareCars($("#carOne").value, $("#carTwo").value));
  $("#carGrid").addEventListener("click", event => {
    const button = event.target.closest("[data-compare]");
    if (!button) return;
    const id = button.dataset.compare;
    if ($("#carOne").value === id) $("#carTwo").selectedIndex = (cars.findIndex(car => String(car.id) !== id));
    else $("#carOne").value = id;
    location.hash = "compare";
    toast("Car added to the comparison selector.");
  });

  $("#menuBtn").addEventListener("click", () => {
    const opened = $("#nav").classList.toggle("open");
    $("#menuBtn").setAttribute("aria-expanded", String(opened));
  });
  $("#nav").addEventListener("click", event => {
    if (event.target.closest("a")) $("#nav").classList.remove("open");
  });
  $("#themeBtn").addEventListener("click", () => {
    const dark = document.documentElement.dataset.theme !== "dark";
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    $("#themeBtn").textContent = dark ? "Light mode" : "Dark mode";
    try { localStorage.setItem("autocompare_theme", dark ? "dark" : "light"); } catch {}
  });
  try {
    const theme = localStorage.getItem("autocompare_theme");
    if (theme) {
      document.documentElement.dataset.theme = theme;
      $("#themeBtn").textContent = theme === "dark" ? "Light mode" : "Dark mode";
    }
  } catch {}

  $("#loginTab").addEventListener("click", () => setAuthMode("login"));
  $("#signupTab").addEventListener("click", () => setAuthMode("signup"));

  $("#signupForm").addEventListener("submit", event => {
    event.preventDefault();
    const name = $("#signupName").value.trim();
    const email = $("#signupEmail").value.trim().toLowerCase();
    const password = $("#signupPassword").value;
    const message = $("#signupMessage");
    const users = getUsers();
    if (name.length < 2) { message.textContent = "Please enter your full name."; return; }
    if (password.length < 8) { message.textContent = "Use at least 8 characters for the demo password."; return; }
    if (users[email]) { message.textContent = "An account with this email already exists."; return; }
    // Demo only: do not use a real or reused password. Real apps need a secure server.
    users[email] = { name, password };
    if (!saveUsers(users)) { message.textContent = "Browser storage is unavailable. Try another browser."; return; }
    try { sessionStorage.setItem("autocompare_session", JSON.stringify({ name, email })); } catch {}
    message.textContent = "Account created in this browser demo.";
    updateAccountUI();
    toast("Welcome to AutoCompare!");
  });

  $("#loginForm").addEventListener("submit", event => {
    event.preventDefault();
    const email = $("#loginEmail").value.trim().toLowerCase();
    const password = $("#loginPassword").value;
    const user = getUsers()[email];
    if (!user || user.password !== password) {
      $("#loginMessage").textContent = "Email or password is incorrect.";
      return;
    }
    try { sessionStorage.setItem("autocompare_session", JSON.stringify({ name: user.name, email })); } catch {}
    $("#loginMessage").textContent = "You are logged in for this browser session.";
    updateAccountUI();
    toast("Login successful.");
  });

  $("#logoutBtn").addEventListener("click", () => {
    try { sessionStorage.removeItem("autocompare_session"); } catch {}
    updateAccountUI();
    toast("Logged out.");
  });

  renderCars();
  fillCompareOptions();
  updateAccountUI();
});
